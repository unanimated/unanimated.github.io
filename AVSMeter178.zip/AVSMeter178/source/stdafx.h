#if _MSC_VER > 1000
#pragma once
#endif

#include <windows.h>
#include <string>
#include <algorithm>
#include <psapi.h>
#include <tlhelp32.h>
#include <wintrust.h>
#include <imagehlp.h>
#include <conio.h>
#include <iostream>
#include <fstream>
#include <algorithm>

